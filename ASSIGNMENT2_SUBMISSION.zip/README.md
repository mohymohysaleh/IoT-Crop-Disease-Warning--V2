# IoT Crop Disease Early Warning — Assignment 2 (ThingsBoard track)

Student project for **SWAPD 453 Spring 2026**. It wires **ChirpStack v4** LoRaWAN simulation to **ThingsBoard CE** using Docker Compose on the developer workstation.

## Prerequisites

- Docker Desktop (Compose v2)
- Python 3.10+ (`py -3 …` on Windows)

```powershell
py -3 -m pip install -r chirpstack/chirpstack-docker/requirements-assignment.txt
```

## Bring-up

```powershell
cd chirpstack/chirpstack-docker
docker compose pull   # first run downloads ThingsBoard (~GB)
docker compose up -d
```

| Endpoint | Purpose |
|----------|---------|
| http://localhost:8080 | ChirpStack UI |
| http://localhost:8090 | ChirpStack REST (optional automation) |
| http://localhost:9090 | ThingsBoard CE — default `sysadmin@thingsboard.org` / `sysadmin` (**change immediately**) |
| mosquitto `:1883` | Shared MQTT between ChirpStack + integrations |
| ThingsBoard devices `:11883` | Mapped to TB transport MQTT |

### Configure ChirpStack & ThingsBoard (high level)

1. Provision applications/devices + gateways EUIs (`aa00000000000001`, `aa00000000000002`).
2. Install codec [`thingsboard/chirpstack/payload_codec.js`](thingsboard/chirpstack/payload_codec.js) on the matching device profile.
3. Ensure application integration emits MQTT events (`application/+/device/+/event/up`).
4. Paste [`thingsboard/integrations/chirpstack_uplink_converter.js`](thingsboard/integrations/chirpstack_uplink_converter.js) into ThingsBoard MQTT integration uplink converter.
5. Implement rule chain described in [`thingsboard/rule_engine/RULE_CHAIN.md`](thingsboard/rule_engine/RULE_CHAIN.md).

### Run the simulators

```powershell
cd chirpstack/chirpstack-docker
py -3 run_all_nodes.py        # logs under .\logs\
```

Defaults: **300 s** cadence, RNG seed `453`, optional ThingsBoard OTA sidecars if you replace `thingsboard_access_token` values in [`config/devices.json`](chirpstack/chirpstack-docker/config/devices.json) and export `ENABLE_TB_SIDECARS=1` (default).

Environment highlights:

| Variable | Effect |
|----------|--------|
| `THINGSBOARD_MQTT_HOST`, `THINGSBOARD_MQTT_PORT` | MQTT target for sidecars (default `localhost:11883`). |
| `ENABLE_TB_SIDECARS` | Set `0` to skip TB clients even when tokens exist. |
| `TB_OTA_SIMULATE_FAIL` | Forces FAILED `fw_state` for rollback demos. |
| `CHIRPSTACK_REST_TOKEN` | Required for REST helper `simulate_uplink.py`. |

Rollback helper:

```powershell
py -3 thingsboard/scripts/rollback_watchdog.py
```

(Optional attack demo) `thingsboard/scripts/rogue_mqtt_client.py`

## Documentation & deliverables

| Artifact | Path |
|----------|------|
| Printable report (convert to PDF for submission) | [`docs/ASSIGNMENT2_REPORT.md`](docs/ASSIGNMENT2_REPORT.md) |
| Demo outline | [`docs/DEMO_VIDEO_SCRIPT.md`](docs/DEMO_VIDEO_SCRIPT.md) |
| Submission ZIP builder | `py -3 scripts/build_submission_zip.py` → `ASSIGNMENT2_SUBMISSION.zip` |
| Export TB JSON into | `thingsboard/artifacts/exports/` |

## Reference PDFs (course brief)

Files in repo root: `Assignment 2.docx.pdf` (AWS baseline), `Assignment-2_Azure.docx.pdf`, `Assignment_2_ThingsBoard.docx.pdf`.

## License

Upstream ChirpStack Compose skeleton retains its original license; additions for this course deliverable are provided as educational examples only.
